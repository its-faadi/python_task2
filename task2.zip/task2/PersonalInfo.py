def get_personal_info():
    while True:
        # Prompt the user to enter their name
        name = input("Enter your name: ")

        # Validate the age input
        while True:
            try:
                age = int(input("Enter your age: "))
                if age <= 0:
                    print("Age must be a positive integer. Please try again.")
                    continue  # If the age is not positive, ask again
                break  # Break out of the loop if the input is valid
            except ValueError:
                print("Invalid input. Age must be a number. Please try again.")  # If input is not an integer, ask again

        # Validate the salary input
        while True:
            try:
                salary = float(input("Enter your salary: "))
                if salary < 0:
                    print("Salary cannot be negative. Please try again.")
                    continue  # If the salary is negative, ask again
                break  # Break out of the loop if the input is valid
            except ValueError:
                print("Invalid input. Salary must be a number. Please try again.")  # If input is not a float, ask again

        # Output the collected information
        print(f"Hello, {name}, you are {age} years old and your salary is ${salary:.2f}.")

        # Ask the user if they want to enter another person's information
        repeat = input("Do you want to enter another person's information? (yes/no): ").strip().lower()
        if repeat != 'yes':
            break  # Exit the loop if the user does not want to continue

# Call the function to start the program
get_personal_info()